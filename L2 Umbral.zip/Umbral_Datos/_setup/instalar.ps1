$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$Root = $PSScriptRoot
$RuntimeDataDir = Split-Path $Root -Parent
$PackageRoot = Split-Path $RuntimeDataDir -Parent
$RuntimeFolderName = Split-Path $RuntimeDataDir -Leaf
$Temp = Join-Path $env:TEMP 'L2AlarmSetup'
$PythonHome = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313'
$UserDataDir = Join-Path $env:LOCALAPPDATA 'Umbral'
$PreferredPython = Join-Path $PythonHome 'python.exe'
$Python = $null
$PythonUrl = 'https://www.python.org/ftp/python/3.13.17/python-3.13.17-amd64.exe'
$TesseractUrl = 'https://github.com/tesseract-ocr/tesseract/releases/download/5.5.3/tesseract-ocr-w64-setup-5.5.3.20260724.exe'
$ProgramFilesX86 = [Environment]::GetFolderPath('ProgramFilesX86')
$TessInstaller = Join-Path $Temp 'tesseract-setup.exe'
$TessExe = $null
$PythonPackageImports = [ordered]@{
    'pyinstaller' = 'import PyInstaller; import PyInstaller.__main__'
    'mss' = 'import mss'
    'opencv-python' = 'import cv2'
    'numpy' = 'import numpy'
    'pytesseract' = 'import pytesseract'
    'customtkinter' = 'import customtkinter'
    'pillow' = 'from PIL import Image'
}
function Say($Text) { Write-Host "`n$Text" -ForegroundColor Cyan }
function Download($Url, $Path) { Write-Host "Descargando: $([IO.Path]::GetFileName($Path))"; Invoke-WebRequest -Uri $Url -OutFile $Path -UseBasicParsing }
function Get-CompatiblePython($Candidate) {
    if (!$Candidate -or !(Test-Path $Candidate -PathType Leaf)) { return $null }
    if ($Candidate -match '\\WindowsApps\\') { return $null }
    try {
        $versionText = & $Candidate -c "import sys; print('{}.{}'.format(sys.version_info.major, sys.version_info.minor))" 2>$null
        if ($LASTEXITCODE -ne 0) { return $null }
        $parts = ([string]$versionText).Trim().Split('.')
        if ($parts.Length -ne 2 -or [int]$parts[0] -ne 3 -or [int]$parts[1] -lt 10 -or [int]$parts[1] -gt 13) { return $null }
        & $Candidate -m pip --version 2>$null | Out-Null
        if ($LASTEXITCODE -ne 0) { return $null }
        return $Candidate
    } catch { return $null }
}
function Get-MissingPythonPackages($Candidate) {
    $missing = [System.Collections.Generic.List[string]]::new()
    foreach ($package in $PythonPackageImports.Keys) {
        $previousPreference = $ErrorActionPreference
        try {
            $ErrorActionPreference = 'Continue'
            & $Candidate -c $PythonPackageImports[$package] 2>$null | Out-Null
            if ($LASTEXITCODE -ne 0) { $missing.Add($package) }
        } catch {
            $missing.Add($package)
        } finally {
            $ErrorActionPreference = $previousPreference
        }
    }
    return $missing.ToArray()
}
function Find-Python {
    $candidates = [System.Collections.Generic.List[string]]::new()
    $candidates.Add($PreferredPython)
    foreach ($command in (Get-Command 'python.exe' -All -ErrorAction SilentlyContinue)) {
        if ($command.Source) { $candidates.Add($command.Source) }
    }
    $pythonRoots = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Python'),
        (Join-Path $env:ProgramFiles 'Python'),
        (Join-Path $ProgramFilesX86 'Python')
    )
    foreach ($pythonRoot in $pythonRoots) {
        if (Test-Path $pythonRoot) {
            foreach ($folder in (Get-ChildItem -Path $pythonRoot -Directory -ErrorAction SilentlyContinue)) {
                $candidates.Add((Join-Path $folder.FullName 'python.exe'))
            }
        }
    }
    foreach ($registryRoot in @(
        'HKCU:\Software\Python\PythonCore',
        'HKLM:\Software\Python\PythonCore',
        'HKLM:\Software\WOW6432Node\Python\PythonCore'
    )) {
        if (Test-Path $registryRoot) {
            foreach ($versionKey in (Get-ChildItem -Path $registryRoot -ErrorAction SilentlyContinue)) {
                foreach ($installKeyPath in @($versionKey.PSPath, (Join-Path $versionKey.PSPath 'InstallPath'))) {
                    if (Test-Path $installKeyPath) {
                        $registered = (Get-Item -Path $installKeyPath).GetValue('')
                        if ($registered) {
                            if ([IO.Path]::GetFileName($registered) -ieq 'python.exe') {
                                $candidates.Add($registered)
                            } else {
                                $candidates.Add((Join-Path $registered 'python.exe'))
                            }
                        }
                    }
                }
            }
        }
    }
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        $usable = Get-CompatiblePython $candidate
        if ($usable) { return $usable }
    }
    return $null
}
function Get-CompatibleTesseract($Candidate) {
    if (!$Candidate -or !(Test-Path $Candidate -PathType Leaf)) { return $null }
    try {
        $output = & $Candidate --version 2>$null
        $exitCode = $LASTEXITCODE
        $versionLine = [string]($output | Select-Object -First 1)
        if ($exitCode -ne 0 -or $versionLine -notmatch '^tesseract\s+v?\d') { return $null }
        $tessData = Join-Path (Split-Path $Candidate) 'tessdata'
        $englishData = Join-Path $tessData 'eng.traineddata'
        if (!(Test-Path $englishData -PathType Leaf) -or (Get-Item $englishData).Length -le 0) { return $null }
        $languages = & $Candidate --tessdata-dir $tessData --list-langs 2>$null
        $languageExitCode = $LASTEXITCODE
        $languageText = [string]($languages -join "`n")
        if ($languageExitCode -ne 0 -or $languageText -notmatch '(?m)^\s*eng\s*$') { return $null }
        return $Candidate
    } catch { return $null }
}
function Find-Tesseract {
    $candidates = [System.Collections.Generic.List[string]]::new()
    foreach ($path in @(
        (Join-Path $env:ProgramFiles 'Tesseract-OCR\tesseract.exe'),
        (Join-Path $ProgramFilesX86 'Tesseract-OCR\tesseract.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Tesseract-OCR\tesseract.exe'),
        (Join-Path $env:LOCALAPPDATA 'Tesseract-OCR\tesseract.exe')
    )) { $candidates.Add($path) }
    foreach ($drive in (Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
        foreach ($relative in @(
            'Program Files\Tesseract-OCR\tesseract.exe',
            'Program Files (x86)\Tesseract-OCR\tesseract.exe',
            'Tesseract-OCR\tesseract.exe'
        )) { $candidates.Add((Join-Path $drive.Root $relative)) }
    }
    foreach ($command in (Get-Command 'tesseract.exe' -All -ErrorAction SilentlyContinue)) {
        if ($command.Source) { $candidates.Add($command.Source) }
    }
    foreach ($registryPath in @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\tesseract.exe',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\tesseract.exe',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\tesseract.exe'
    )) {
        if (Test-Path $registryPath) {
            $registered = (Get-Item -Path $registryPath).GetValue('')
            if ($registered) { $candidates.Add($registered) }
        }
    }
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        $usable = Get-CompatibleTesseract $candidate
        if ($usable) { return $usable }
    }
    return $null
}
try {
    New-Item -ItemType Directory -Force -Path $Temp | Out-Null
    Say 'Paso 1 de 4: preparando Python'
    $Python = Find-Python
    if (!$Python) {
        if (Test-Path $PreferredPython) {
            $PythonHome = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313_Umbral'
            $PreferredPython = Join-Path $PythonHome 'python.exe'
        }
        $Python = $PreferredPython
        $PythonInstaller = Join-Path $Temp 'python-setup.exe'
        Download $PythonUrl $PythonInstaller
        Write-Host 'Instalando Python en esta computadora...'
        $targetArg = 'TargetDir="{0}"' -f $PythonHome
        $pyInstallArgs = '/quiet InstallAllUsers=0 PrependPath=0 Include_pip=1 Include_tcltk=1 Include_test=0 Shortcuts=0 ' + $targetArg
        $p = Start-Process -FilePath $PythonInstaller -ArgumentList $pyInstallArgs -Wait -PassThru
        if ($p.ExitCode -ne 0 -or !(Get-CompatiblePython $Python)) { throw 'No se pudo instalar Python.' }
    } else {
        Write-Host "Python compatible ya instalado; se reutilizara: $Python"
    }
    Say 'Paso 2 de 4: comprobando Tesseract para leer el chat'
    $TessExe = Find-Tesseract
    if (!$TessExe) {
        Write-Host 'No se encontro Tesseract. Se instalara ahora.'
        Download $TesseractUrl $TessInstaller
        Write-Host 'Instalando Tesseract. Windows puede pedir permiso; elegi Si.'
        $p = Start-Process -FilePath $TessInstaller -ArgumentList '/S' -Verb RunAs -Wait -PassThru
        if ($p.ExitCode -ne 0) { throw 'No se pudo instalar Tesseract.' }
        $TessExe = Find-Tesseract
    } else {
        Write-Host "Tesseract ya instalado; se reutilizara: $TessExe"
    }
    if (!$TessExe) { throw 'No se encontro una instalacion funcional de Tesseract con los datos de English.' }
    Say 'Paso 3 de 4: comprobando componentes y preparando la aplicacion'
    foreach ($file in @('l2_alarm_ui.py','captcha.png','alarm.wav','chat.wav','icono_umbral.png','icono_umbral.ico')) { if (!(Test-Path (Join-Path $Root $file))) { throw "Falta $file en el ZIP. Volve a extraer todos los archivos." } }
    $MissingPythonPackages = @(Get-MissingPythonPackages $Python)
    if ($MissingPythonPackages.Count -gt 0) {
        Write-Host ('Instalando los paquetes que faltan o no funcionan: ' + ($MissingPythonPackages -join ', '))
        & $Python -m pip install @MissingPythonPackages
        if ($LASTEXITCODE -ne 0) { throw 'Fallo la instalacion de los componentes de la aplicacion.' }
        $MissingPythonPackages = @(Get-MissingPythonPackages $Python)
        if ($MissingPythonPackages.Count -gt 0) {
            Write-Host ('Algunos paquetes siguen fallando; se repararan: ' + ($MissingPythonPackages -join ', '))
            & $Python -m pip install --force-reinstall @MissingPythonPackages
            if ($LASTEXITCODE -ne 0) { throw 'No se pudieron reparar los componentes de Python.' }
            $MissingPythonPackages = @(Get-MissingPythonPackages $Python)
            if ($MissingPythonPackages.Count -gt 0) { throw ('Siguen sin funcionar estos paquetes: ' + ($MissingPythonPackages -join ', ')) }
        }
    } else {
        Write-Host 'Los componentes de Python ya funcionan; se reutilizaran.'
    }
    $BuildRoot = Join-Path $Temp 'UmbralBuild'
    $BuildDist = Join-Path $BuildRoot 'dist'
    $BuildWork = Join-Path $BuildRoot 'work'
    New-Item -ItemType Directory -Force -Path $BuildRoot,$BuildDist,$BuildWork | Out-Null
    $AppScript = Join-Path $Root 'l2_alarm_ui.py'
    $IconFile = Join-Path $Root 'icono_umbral.ico'
    $CaptchaFile = Join-Path $Root 'captcha.png'
    $AlarmSoundFile = Join-Path $Root 'alarm.wav'
    $ChatSoundFile = Join-Path $Root 'chat.wav'
    $IconPngFile = Join-Path $Root 'icono_umbral.png'
    Push-Location $Root
    try {
        $PyInstallerArgs = @(
            '-m','PyInstaller','--noconfirm','--clean','--onedir','--windowed',
            '--name','Umbral','--icon',$IconFile,'--contents-directory',$RuntimeFolderName,
            '--collect-all','customtkinter',
            '--distpath',$BuildDist,'--workpath',$BuildWork,'--specpath',$BuildRoot,
            '--add-data',($CaptchaFile + ';.'),'--add-data',($AlarmSoundFile + ';.'),
            '--add-data',($ChatSoundFile + ';.'),'--add-data',($IconPngFile + ';.'),
            '--add-data',($IconFile + ';.'),$AppScript
        )
        & $Python @PyInstallerArgs
        if ($LASTEXITCODE -ne 0) { throw 'No se pudo crear la aplicacion.' }
    } finally { Pop-Location }
    Say 'Paso 4 de 4: terminando'
    $BuiltDir = Join-Path $BuildDist 'Umbral'
    $BuiltRuntimeDir = Join-Path $BuiltDir $RuntimeFolderName
    $InstallDir = $PackageRoot
    $PreviousInstallDir = Join-Path $env:LOCALAPPDATA 'Programs\Umbral'
    $LegacyInstallDir = Join-Path $env:LOCALAPPDATA 'Programs\Alarma Lineage 2'
    $Exe = Join-Path $InstallDir 'Umbral.exe'
    if (!(Test-Path (Join-Path $BuiltDir 'Umbral.exe'))) { throw 'No encuentro el ejecutable que se acaba de crear.' }
    if (!(Test-Path $BuiltRuntimeDir -PathType Container)) { throw 'No encuentro la carpeta de datos creada por PyInstaller.' }
    New-Item -ItemType Directory -Force -Path $UserDataDir | Out-Null
    $TesseractHint = Join-Path $UserDataDir 'tesseract_path.txt'
    [IO.File]::WriteAllText($TesseractHint, $TessExe)
    foreach ($name in @('chat_area.json','l2_alarm_settings.json','captcha_custom.png','captcha_custom.wav','chat_custom.wav')) {
        $destination = Join-Path $UserDataDir $name
        if (Test-Path $destination) { continue }
        foreach ($sourceDir in @($PreviousInstallDir, $LegacyInstallDir)) {
            $old = Join-Path $sourceDir $name
            if (Test-Path $old) {
                Copy-Item $old $destination -Force
                break
            }
        }
    }
    $assetMigrations = @(
        @{ Source = 'captcha.png'; Target = 'captcha_custom.png' },
        @{ Source = 'alarm.wav'; Target = 'captcha_custom.wav' },
        @{ Source = 'chat.wav'; Target = 'chat_custom.wav' }
    )
    foreach ($migration in $assetMigrations) {
        $destination = Join-Path $UserDataDir $migration.Target
        if (Test-Path $destination) { continue }
        $reference = Join-Path $Root $migration.Source
        $candidates = @()
        foreach ($sourceDir in @($PreviousInstallDir, $LegacyInstallDir)) {
            $candidates += (Join-Path $sourceDir $migration.Source)
            $candidates += (Join-Path $sourceDir ('_internal\' + $migration.Source))
            $candidates += (Join-Path $sourceDir ($RuntimeFolderName + '\' + $migration.Source))
        }
        foreach ($candidate in $candidates) {
            if (Test-Path $candidate) {
                if ((Get-FileHash $candidate).Hash -ne (Get-FileHash $reference).Hash) {
                    Copy-Item $candidate $destination -Force
                }
                break
            }
        }
    }
    New-Item -ItemType Directory -Force -Path $InstallDir,$RuntimeDataDir | Out-Null
    foreach ($item in (Get-ChildItem -LiteralPath $RuntimeDataDir -Force)) {
        if ($item.Name -ne '_setup') { Remove-Item -LiteralPath $item.FullName -Recurse -Force }
    }
    Copy-Item (Join-Path $BuiltRuntimeDir '*') $RuntimeDataDir -Recurse -Force
    Copy-Item (Join-Path $BuiltDir 'Umbral.exe') $Exe -Force
    if (Test-Path $PreviousInstallDir) { Remove-Item $PreviousInstallDir -Recurse -Force }
    if (Test-Path $LegacyInstallDir) { Remove-Item $LegacyInstallDir -Recurse -Force }
    $Desktop = [Environment]::GetFolderPath('Desktop')
    $OldShortcut = Join-Path $Desktop 'Alarma Lineage 2.lnk'
    if (Test-Path $OldShortcut) { Remove-Item $OldShortcut -Force }
    $ShortcutPath = Join-Path $Desktop 'Umbral.lnk'
    $Shell = New-Object -ComObject WScript.Shell
    $Shortcut = $Shell.CreateShortcut($ShortcutPath)
    $Shortcut.TargetPath = $Exe
    $Shortcut.WorkingDirectory = $InstallDir
    $Shortcut.IconLocation = "$Exe,0"
    $Shortcut.Save()
    Remove-Item $Temp -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host 'Listo. Umbral quedo instalado y se creo un acceso directo en el Escritorio.' -ForegroundColor Green
    Start-Process -FilePath $Exe
    exit 0
} catch {
    Write-Host "`nERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'No cierres esta ventana todavia; podes sacar una foto para pedir ayuda.'
    exit 1
}
