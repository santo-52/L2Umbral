"""Umbral: observa el monitor elegido y reproduce avisos, sin enviar entradas."""
import json
import os
import queue
import re
import shutil
import sys
import threading
import time
import urllib.request
from difflib import SequenceMatcher
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog

import cv2
import customtkinter as ctk
import mss
import numpy as np
import winsound
from PIL import Image, ImageTk

RESOURCE_BASE = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
BASE = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "Umbral"
DATA_DIR.mkdir(parents=True, exist_ok=True)
SETTINGS = DATA_DIR / "l2_alarm_settings.json"
CHAT_AREA = DATA_DIR / "chat_area.json"
CUSTOM_CAPTCHA = DATA_DIR / "captcha_custom.png"
CUSTOM_CAPTCHA_SOUND = DATA_DIR / "captcha_custom.wav"
CUSTOM_CHAT_SOUND = DATA_DIR / "chat_custom.wav"
TESSERACT_HINT = DATA_DIR / "tesseract_path.txt"
CHANNEL_PATTERN = re.compile(r"^\s*(?:ordinary|world|admin)\s*:\s+\S", re.I)
THRESHOLD, CAPTCHA_INTERVAL, CHAT_INTERVAL = 0.85, 0.5, 2.0
DEFAULT_MONITOR = 1

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")


class ToolTip:
    def __init__(self, widget, text):
        self.widget, self.text, self.tip = widget, text, None
        widget.bind("<Enter>", self.show, add="+")
        widget.bind("<Leave>", self.hide, add="+")

    def show(self, _event=None):
        if self.tip:
            return
        self.tip = win = tk.Toplevel(self.widget)
        win.wm_overrideredirect(True)
        x = self.widget.winfo_rootx() + 12
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 5
        win.wm_geometry(f"+{x}+{y}")
        tk.Label(
            win, text=self.text, justify="left", background="#fff8d7",
            relief="solid", borderwidth=1, padx=9, pady=7, wraplength=370,
        ).pack()

    def hide(self, _event=None):
        if self.tip:
            self.tip.destroy()
            self.tip = None


def asset(name):
    """Use a file beside the EXE when present, else the bundled copy."""
    external = BASE / name
    return external if external.exists() else RESOURCE_BASE / name


def load_ocr():
    import pytesseract

    candidates = [RESOURCE_BASE / "Tesseract-OCR" / "tesseract.exe"]
    try:
        saved_path = TESSERACT_HINT.read_text(encoding="utf-8-sig").strip()
        if saved_path:
            candidates.insert(0, Path(saved_path))
    except Exception:
        pass
    on_path = shutil.which("tesseract.exe") or shutil.which("tesseract")
    if on_path:
        candidates.append(Path(on_path))
    for variable in ("ProgramFiles", "ProgramFiles(x86)"):
        root = os.environ.get(variable)
        if root:
            candidates.append(Path(root) / "Tesseract-OCR" / "tesseract.exe")
    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        candidates.extend([
            Path(local_app_data) / "Programs" / "Tesseract-OCR" / "tesseract.exe",
            Path(local_app_data) / "Tesseract-OCR" / "tesseract.exe",
        ])
    for path in candidates:
        if path and Path(path).is_file():
            pytesseract.pytesseract.tesseract_cmd = str(path)
            tessdata = Path(path).parent / "tessdata"
            if tessdata.is_dir():
                os.environ["TESSDATA_PREFIX"] = str(tessdata)
            break
    pytesseract.get_tesseract_version()
    return pytesseract


class AlarmUI:
    BG = "#171522"
    CARD = "#211d30"
    CARD_ALT = "#191626"
    PURPLE = "#8b5cf6"
    PURPLE_HOVER = "#7446dc"
    CYAN = "#06b6d4"
    TEXT = "#f3f0fa"
    MUTED = "#aaa4b8"

    def __init__(self, root):
        self.root = root
        root.title("Umbral")
        root.geometry("970x740")
        root.minsize(900, 690)
        root.configure(fg_color=self.BG)
        self._set_window_icon()

        self.events = queue.Queue()
        self.stop_event = None
        self.worker = None
        self.start_task = None
        self.starting = False
        self.monitor_data = []
        self.monitor_names = []
        self.config = self.read_settings()
        self.monitor_var = tk.StringVar()
        self.ntfy_var = tk.StringVar(value=self.config.get("ntfy_topic", ""))
        self.ntfy_enabled = tk.BooleanVar(
            value=self.config.get("ntfy_enabled", False)
        )
        self.status = tk.StringVar(value="Detenida")
        self.captcha_sound_var = tk.StringVar()
        self.chat_sound_var = tk.StringVar()
        self.captcha_template_var = tk.StringVar()
        self.build()
        self.refresh_monitors()
        self.refresh_file_labels()
        root.after(150, self.process_events)
        root.protocol("WM_DELETE_WINDOW", self.close)

    def _set_window_icon(self):
        try:
            self.root.iconbitmap(str(asset("icono_umbral.ico")))
        except Exception:
            pass
        try:
            image = Image.open(asset("icono_umbral.png"))
            self._window_icon = ImageTk.PhotoImage(image)
            self.root.iconphoto(True, self._window_icon)
        except Exception:
            pass

    def read_settings(self):
        try:
            data = json.loads(SETTINGS.read_text(encoding="utf-8"))
        except Exception:
            data = {}
        data.setdefault("monitor", DEFAULT_MONITOR)
        data.setdefault("nicknames", [])
        if CUSTOM_CAPTCHA.exists():
            data.setdefault("custom_captcha", True)
            data.setdefault("captcha_monitor", data.get("monitor", DEFAULT_MONITOR))
        if "chat_monitor" not in data:
            data["chat_monitor"] = data["monitor"] if CHAT_AREA.exists() else None
        return data

    def save_settings(self):
        try:
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            SETTINGS.write_text(json.dumps(self.config, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception as exc:
            self.add_log("No pude guardar la configuracion: " + str(exc))

    def build(self):
        page = ctk.CTkFrame(self.root, fg_color="transparent")
        page.pack(fill="both", expand=True, padx=22, pady=18)
        page.grid_columnconfigure(0, weight=1)
        page.grid_rowconfigure(1, weight=1)

        header = ctk.CTkFrame(page, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", pady=(0, 15))
        header.grid_columnconfigure(0, weight=1)
        title_box = ctk.CTkFrame(header, fg_color="transparent")
        title_box.grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(
            title_box, text="Umbral", font=("Segoe UI", 36, "bold"),
            text_color="#8a73ff",
        ).pack(anchor="w")
        ctk.CTkLabel(
            title_box, text="Esta app no envia teclas ni clics.",
            font=("Segoe UI", 13), text_color=self.MUTED,
        ).pack(anchor="w", pady=(1, 0))

        try:
            logo = Image.open(asset("icono_umbral.png"))
            self.logo_image = ctk.CTkImage(
                light_image=logo, dark_image=logo, size=(108, 108)
            )
            self.logo_label = ctk.CTkLabel(
                header, image=self.logo_image, text="", fg_color="transparent"
            )
            self.logo_label.grid(row=0, column=1, sticky="e", padx=(12, 3))
        except Exception:
            pass

        content = ctk.CTkFrame(page, fg_color="transparent")
        content.grid(row=1, column=0, sticky="nsew")
        content.grid_columnconfigure(0, weight=3, uniform="columns")
        content.grid_columnconfigure(1, weight=2, uniform="columns")
        content.grid_rowconfigure(0, weight=1)

        left = ctk.CTkFrame(content, fg_color="transparent")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 9))
        left.grid_columnconfigure(0, weight=1)

        control = self.make_card(left, "Vigilancia")
        control.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        control.grid_columnconfigure(0, weight=1)
        monitor_row = ctk.CTkFrame(control, fg_color="transparent")
        monitor_row.grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 10))
        ctk.CTkLabel(monitor_row, text="Monitor:", font=("Segoe UI", 13, "bold"),
                     text_color=self.TEXT).pack(side="left", padx=(0, 10))
        self.monitor_combo = ctk.CTkComboBox(
            monitor_row, variable=self.monitor_var, values=[],
            state="readonly", width=250, height=34,
            fg_color="#171522", border_color="#453b60",
            button_color="#5943a1", button_hover_color=self.PURPLE_HOVER,
        )
        self.monitor_combo.pack(side="left", fill="x", expand=True)
        self.monitor_combo.configure(command=self.monitor_changed)

        actions = ctk.CTkFrame(control, fg_color="transparent")
        actions.grid(row=2, column=0, sticky="ew", padx=14)
        for column in range(3):
            actions.grid_columnconfigure(column, weight=1)
        self.start_btn = ctk.CTkButton(
            actions, text="▶  Iniciar alarma", command=self.start,
            fg_color=self.CYAN, hover_color="#0891b2", text_color="#ffffff",
            font=("Segoe UI", 13, "bold"), height=38, corner_radius=9,
        )
        self.start_btn.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        ToolTip(self.start_btn, "Vigila captcha y produce sonido.")
        self.stop_btn = ctk.CTkButton(
            actions, text="■  Detener", command=self.stop,
            fg_color="#373344", hover_color="#494357", text_color="#d7d2e0",
            height=38, corner_radius=9, state="disabled",
        )
        self.stop_btn.grid(row=0, column=1, sticky="ew", padx=6)

        chat_cell = ctk.CTkFrame(actions, fg_color="transparent")
        chat_cell.grid(row=0, column=2, sticky="ew", padx=(6, 0))
        chat_cell.grid_columnconfigure(0, weight=1)
        self.select_chat_btn = ctk.CTkButton(
            chat_cell, text="💬  Seleccionar chat", command=self.select_chat,
            fg_color="#403754", hover_color="#55486e", text_color="#eee9f8",
            height=38, corner_radius=9,
        )
        self.select_chat_btn.grid(row=0, column=0, sticky="ew")
        self.info_label = ctk.CTkLabel(
            chat_cell, text="ⓘ", width=22, cursor="question_arrow",
            text_color="#bca8ff", font=("Segoe UI", 17, "bold"),
        )
        self.info_label.grid(row=0, column=1, padx=(5, 0))
        ToolTip(
            self.info_label,
            "Marca toda el area donde aparecen los nombres y mensajes del chat. "
            "Al terminar, apreta ENTER para confirmar.\n\n"
            "Esta funcion vigila mensajes de administradores. No envia teclas ni clics.",
        )
        self.nicknames_btn = ctk.CTkButton(
            chat_cell, text="Nicknames", command=self.edit_nicknames,
            fg_color="#302942", hover_color="#443659", text_color="#e9d5ff",
            height=32, corner_radius=8,
        )
        self.nicknames_btn.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(7, 0))
        ToolTip(
            self.nicknames_btn,
            "Escribi los nicknames que queres vigilar separados por un punto y coma ;",
        )
        actions.grid_rowconfigure(1, minsize=38)

        captcha_box = ctk.CTkFrame(control, fg_color=self.CARD_ALT, corner_radius=10)
        captcha_box.grid(row=3, column=0, sticky="ew", padx=14, pady=(12, 14))
        captcha_box.grid_columnconfigure(1, weight=1)
        self.select_captcha_btn = ctk.CTkButton(
            captcha_box, text="▧  Capturar captcha", command=self.select_captcha,
            fg_color=self.PURPLE, hover_color=self.PURPLE_HOVER,
            text_color="#ffffff", height=36, corner_radius=8,
        )
        self.select_captcha_btn.grid(row=0, column=0, rowspan=2, padx=10, pady=10)
        ToolTip(
            self.select_captcha_btn,
            "Si estas jugando un server diferente al OW, cuando te aparezca el captcha "
            "selecciona esta opcion asi la app puede reconocerlo.\n\n"
            "Marca una parte fija del captcha, como el borde o el titulo, y apreta ENTER.",
        )
        ctk.CTkLabel(
            captcha_box, text="Captura del captcha", text_color=self.TEXT,
            font=("Segoe UI", 12, "bold"),
        ).grid(row=0, column=1, sticky="sw", padx=(4, 10), pady=(9, 0))
        ctk.CTkLabel(
            captcha_box, textvariable=self.captcha_template_var, text_color=self.MUTED,
            font=("Segoe UI", 11), anchor="w",
        ).grid(row=1, column=1, sticky="nw", padx=(4, 10), pady=(1, 9))
        captcha_tools = ctk.CTkFrame(captcha_box, fg_color="transparent")
        captcha_tools.grid(row=2, column=1, sticky="w", padx=(4, 10), pady=(0, 10))
        self.preview_captcha_btn = ctk.CTkButton(
            captcha_tools, text="Ver captura", width=112, height=28,
            command=self.preview_captcha,
            fg_color="#403754", hover_color="#55486e", text_color=self.TEXT,
        )
        self.preview_captcha_btn.pack(side="left", padx=(0, 6))
        ToolTip(self.preview_captcha_btn, "Muestra la imagen que Umbral va a comparar con la pantalla.")
        self.check_captcha_btn = ctk.CTkButton(
            captcha_tools, text="Probar ahora", width=112, height=28,
            command=self.test_captcha_match,
            fg_color="#4f46e5", hover_color="#4338ca", text_color="#ffffff",
        )
        self.check_captcha_btn.pack(side="left")
        ToolTip(
            self.check_captcha_btn,
            "Compara la pantalla actual con la captura activa y anota el resultado en el registro.",
        )

        audio = self.make_card(left, "Sonidos")
        audio.grid(row=1, column=0, sticky="ew")
        audio.grid_columnconfigure(1, weight=1)
        self.build_sound_row(audio, 1, "Captcha", "captcha")
        self.build_sound_row(audio, 2, "Chat", "chat")

        right = ctk.CTkFrame(content, fg_color="transparent")
        right.grid(row=0, column=1, sticky="nsew", padx=(9, 0))
        right.grid_columnconfigure(0, weight=1)
        right.grid_rowconfigure(1, weight=1)

        ntfy = self.make_card(right, "Avisos al celular con ntfy")
        ntfy.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        ntfy.grid_columnconfigure(0, weight=1)
        self.ntfy_check = ctk.CTkCheckBox(
            ntfy, text="Activar notificaciones", variable=self.ntfy_enabled,
            command=self.ntfy_toggle, fg_color=self.PURPLE,
            hover_color=self.PURPLE_HOVER, text_color=self.TEXT,
        )
        self.ntfy_check.grid(row=1, column=0, columnspan=2, sticky="w", padx=14, pady=(0, 8))
        ctk.CTkLabel(ntfy, text="Mi codigo:", text_color=self.TEXT).grid(
            row=2, column=0, sticky="w", padx=14, pady=(2, 6)
        )
        self.ntfy_entry = ctk.CTkEntry(
            ntfy, textvariable=self.ntfy_var, placeholder_text="Tu codigo ntfy",
            fg_color="#171522", border_color="#453b60",
        )
        self.ntfy_entry.grid(row=3, column=0, sticky="ew", padx=(14, 6), pady=(0, 8))
        self.ntfy_test_btn = ctk.CTkButton(
            ntfy, text="Probar", command=self.test_ntfy, width=78,
            fg_color="#403754", hover_color="#55486e", text_color=self.TEXT,
        )
        self.ntfy_test_btn.grid(row=3, column=1, sticky="e", padx=(0, 14), pady=(0, 8))
        ctk.CTkLabel(
            ntfy,
            text="Instala ntfy en el celular y suscribite al mismo codigo. Elegi uno unico y dificil de adivinar.",
            wraplength=315, justify="left", text_color=self.MUTED,
            font=("Segoe UI", 11),
        ).grid(row=4, column=0, columnspan=2, sticky="w", padx=14, pady=(0, 13))

        activity = self.make_card(right, "Estado y actividad")
        activity.grid(row=1, column=0, sticky="nsew")
        activity.grid_columnconfigure(0, weight=1)
        activity.grid_rowconfigure(3, weight=1)
        status_row = ctk.CTkFrame(activity, fg_color="transparent")
        status_row.grid(row=1, column=0, sticky="ew", padx=14, pady=(0, 9))
        ctk.CTkLabel(status_row, text="Estado:", text_color=self.TEXT,
                     font=("Segoe UI", 13, "bold")).pack(side="left")
        self.status_label = ctk.CTkLabel(
            status_row, textvariable=self.status, text_color="#f87171",
            font=("Segoe UI", 13, "bold"),
        )
        self.status_label.pack(side="left", padx=(6, 0))
        ctk.CTkLabel(activity, text="Actividad", text_color=self.MUTED,
                     font=("Segoe UI", 12)).grid(row=2, column=0, sticky="nw", padx=14)
        self.log = ctk.CTkTextbox(
            activity, height=260, corner_radius=9, wrap="word",
            fg_color="#12101c", text_color="#9fe3c4",
            font=("Consolas", 11), border_width=0,
        )
        self.log.grid(row=3, column=0, sticky="nsew", padx=14, pady=(5, 14))
        self.log.configure(state="disabled")
        self.ntfy_toggle()
        self.refresh_nickname_label()

    def make_card(self, parent, title):
        card = ctk.CTkFrame(
            parent, fg_color=self.CARD, border_color="#39324b",
            border_width=1, corner_radius=13,
        )
        ctk.CTkLabel(
            card, text=title, font=("Segoe UI", 14, "bold"),
            text_color="#c4a7ff",
        ).grid(row=0, column=0, sticky="w", padx=14, pady=(12, 10))
        return card

    def build_sound_row(self, parent, row, label, kind):
        ctk.CTkLabel(
            parent, text=label, text_color=self.TEXT, width=65,
            anchor="w", font=("Segoe UI", 12, "bold"),
        ).grid(row=row, column=0, sticky="w", padx=(14, 4), pady=(0, 9))
        var = self.captcha_sound_var if kind == "captcha" else self.chat_sound_var
        ctk.CTkLabel(
            parent, textvariable=var, text_color=self.MUTED,
            anchor="w", font=("Segoe UI", 10),
        ).grid(row=row, column=1, sticky="ew", padx=4, pady=(0, 9))
        button = ctk.CTkButton(
            parent, text="Adjuntar .wav", width=108, height=31,
            command=lambda k=kind: self.choose_sound(k),
            fg_color="#403754", hover_color="#55486e", text_color=self.TEXT,
        )
        button.grid(row=row, column=2, padx=(4, 5), pady=(0, 9))
        if kind == "captcha":
            self.captcha_sound_btn = button
        else:
            self.chat_sound_btn = button
        test = ctk.CTkButton(
            parent, text="▶", width=42, height=31,
            command=lambda k=kind: self.test_sound(k),
            fg_color="#4f46e5", hover_color="#4338ca", text_color="#ffffff",
        )
        test.grid(row=row, column=3, padx=(0, 14), pady=(0, 9))
        if kind == "captcha":
            self.test_captcha_btn = test
        else:
            self.test_chat_btn = test

    def refresh_file_labels(self):
        self.captcha_sound_var.set(self.sound_label("captcha"))
        self.chat_sound_var.set(self.sound_label("chat"))
        if self.config.get("custom_captcha") and CUSTOM_CAPTCHA.exists():
            self.captcha_template_var.set("Activa: captura personalizada.")
        elif CUSTOM_CAPTCHA.exists():
            self.captcha_template_var.set(
                "Personalizada guardada, pero inactiva. Se usa la incluida."
            )
        else:
            self.captcha_template_var.set("Activa: captura incluida para OW.")

    def captcha_template_path(self):
        if self.config.get("custom_captcha") and CUSTOM_CAPTCHA.exists():
            return CUSTOM_CAPTCHA, True
        return asset("captcha.png"), False

    def preview_captcha(self):
        path, custom = self.captcha_template_path()
        if not path.exists():
            messagebox.showerror("No se encontro la captura", str(path))
            return
        try:
            image = Image.open(path).convert("RGB")
            dimensions = f"{image.width} x {image.height} px"
            resampling = getattr(Image, "Resampling", Image)
            image.thumbnail((680, 420), resampling.LANCZOS)
            window = ctk.CTkToplevel(self.root)
            window.title("Captura activa de captcha")
            window.resizable(False, False)
            kind = "Personalizada" if custom else "Incluida para OW"
            ctk.CTkLabel(
                window, text=f"{kind} - {dimensions}", text_color=self.TEXT,
                font=("Segoe UI", 12, "bold"),
            ).pack(padx=14, pady=(14, 8))
            photo = ImageTk.PhotoImage(image)
            preview = ctk.CTkLabel(window, text="", image=photo)
            preview.image = photo
            preview.pack(padx=14, pady=(0, 14))
            window.update_idletasks()
            window.geometry(f"{window.winfo_reqwidth()}x{window.winfo_reqheight()}")
        except Exception as exc:
            messagebox.showerror("No se pudo abrir la captura", str(exc))

    def test_captcha_match(self):
        try:
            _n, monitor = self.chosen()
            path, custom = self.captcha_template_path()
            template = cv2.imdecode(
                np.fromfile(str(path), dtype=np.uint8), cv2.IMREAD_GRAYSCALE
            )
            if template is None or template.size == 0 or template.std() < 1:
                raise RuntimeError("La captura activa no es una imagen valida.")
            if template.shape[0] > monitor["height"] or template.shape[1] > monitor["width"]:
                raise RuntimeError("La captura activa es mas grande que el monitor.")
            source = "personalizada" if custom else "incluida"
            self.add_log("Probando la captura " + source + " en la pantalla actual.")
            threading.Thread(
                target=self.measure_captcha_match,
                args=(monitor, template, source),
                daemon=True,
            ).start()
        except Exception as exc:
            messagebox.showerror("No se pudo probar la captura", str(exc))

    def measure_captcha_match(self, monitor, template, source):
        try:
            with mss.mss() as sct:
                frame = np.array(sct.grab(monitor))[:, :, :3]
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            score = float(cv2.matchTemplate(gray, template, cv2.TM_CCOEFF_NORMED).max())
            verdict = "supera el umbral; deberia detectarse" if score >= THRESHOLD else "no alcanza el umbral"
            self.events.put((
                "log",
                f"Prueba de captcha: {score:.2f} (umbral {THRESHOLD:.2f}); "
                f"{verdict}. Plantilla {source}.",
            ))
        except Exception as exc:
            self.events.put(("log", "No se pudo probar la captura: " + str(exc)))

    def sound_label(self, kind):
        custom_path = CUSTOM_CAPTCHA_SOUND if kind == "captcha" else CUSTOM_CHAT_SOUND
        setting = self.config.get(f"{kind}_sound_label")
        if custom_path.exists():
            return setting or custom_path.name
        default = "alarm.wav" if kind == "captcha" else "chat.wav"
        return f"Incluido: {default}"

    def refresh_nickname_label(self):
        names = self.config.get("nicknames", [])
        label = "Nicknames" if not names else f"Nicknames ({len(names)})"
        self.nicknames_btn.configure(text=label)

    def ntfy_toggle(self):
        state = "normal" if self.ntfy_enabled.get() else "disabled"
        self.ntfy_entry.configure(state=state)
        self.ntfy_test_btn.configure(state=state)

    def persist_ntfy(self):
        self.config["ntfy_topic"] = self.ntfy_var.get().strip()
        self.config["ntfy_enabled"] = bool(self.ntfy_enabled.get())
        self.save_settings()

    def test_ntfy(self):
        topic = self.ntfy_var.get().strip()
        if not self.ntfy_enabled.get():
            messagebox.showinfo("ntfy desactivado", "Marca Activar notificaciones primero.")
            return
        if not topic:
            messagebox.showerror(
                "Falta el codigo",
                "Escribi el mismo codigo que vas a usar en la app ntfy del celular.",
            )
            return
        self.persist_ntfy()
        threading.Thread(target=self.send_test_notice, args=(topic,), daemon=True).start()
        self.add_log("Enviando notificacion de prueba a ntfy.")

    def send_test_notice(self, topic):
        try:
            req = urllib.request.Request(
                "https://ntfy.sh/" + topic,
                data="Prueba de la alarma.".encode("utf-8"),
                headers={"Title": "Umbral", "Priority": "urgent"},
            )
            with urllib.request.urlopen(req, timeout=8):
                pass
            self.events.put(("log", "Notificacion de prueba enviada."))
        except Exception as exc:
            self.events.put(("log", "Fallo la prueba de ntfy: " + str(exc)))

    def refresh_monitors(self):
        try:
            with mss.mss() as sct:
                self.monitor_data = sct.monitors[1:]
            self.monitor_names = [
                f"Monitor {i}: {m['width']} x {m['height']}"
                for i, m in enumerate(self.monitor_data, 1)
            ]
            self.monitor_combo.configure(values=self.monitor_names)
            n = max(1, min(int(self.config.get("monitor", 1)), len(self.monitor_names)))
            self.config["monitor"] = n
            if self.monitor_names:
                self.monitor_var.set(self.monitor_names[n - 1])
        except Exception as exc:
            self.add_log("No pude leer los monitores: " + str(exc))

    def chosen(self):
        selected = self.monitor_var.get()
        if selected not in self.monitor_names:
            raise RuntimeError("Elegi un monitor de la lista.")
        i = self.monitor_names.index(selected)
        return i + 1, self.monitor_data[i]

    def monitor_changed(self, _value=None):
        try:
            n, _mon = self.chosen()
        except Exception:
            return
        self.config["monitor"] = n
        self.save_settings()
        if self.config.get("chat_monitor") != n and CHAT_AREA.exists():
            self.status.set("Selecciona el chat para este monitor")
        if CUSTOM_CAPTCHA.exists() and self.config.get("captcha_monitor") != n:
            self.status.set("Selecciona el captcha para este monitor")

    def add_log(self, msg):
        self.log.configure(state="normal")
        self.log.insert("end", time.strftime("%H:%M:%S") + "  " + msg + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def select_region(self, kind):
        if self.worker and self.worker.is_alive():
            messagebox.showinfo("Detene la alarma", "Primero apreta Detener.")
            return
        is_chat = kind == "chat"
        title = "Marca el chat y apreta ENTER" if is_chat else "Marca el captcha y apreta ENTER"
        try:
            n, monitor = self.chosen()
            self.root.iconify()
            self.root.update()
            with mss.mss() as sct:
                frame = np.array(sct.grab(monitor))[:, :, :3].copy()
            rect = cv2.selectROI(title, frame, showCrosshair=False, fromCenter=False)
            cv2.destroyAllWindows()
            x, y, w, h = map(int, rect)
            self.root.deiconify()
            self.root.lift()
            if w <= 0 or h <= 0:
                self.add_log("Seleccion cancelada.")
                return
            if is_chat:
                CHAT_AREA.write_text(json.dumps([x, y, w, h]), encoding="utf-8")
                self.config["chat_monitor"] = n
                self.config["monitor"] = n
                self.add_log("Area del chat guardada.")
            else:
                crop = frame[y:y + h, x:x + w]
                ok, encoded = cv2.imencode(".png", crop)
                if not ok:
                    raise RuntimeError("No pude guardar la captura seleccionada.")
                encoded.tofile(str(CUSTOM_CAPTCHA))
                self.config["captcha_monitor"] = n
                self.config["custom_captcha"] = True
                self.config["monitor"] = n
                self.add_log("Captura personalizada del captcha guardada.")
            self.save_settings()
            self.refresh_file_labels()
            self.monitor_var.set(self.monitor_names[n - 1])
            self.status.set(f"{'Chat' if is_chat else 'Captcha'} seleccionado en monitor {n}")
        except Exception as exc:
            cv2.destroyAllWindows()
            self.root.deiconify()
            messagebox.showerror("No se pudo seleccionar el area", str(exc))

    def select_chat(self):
        self.select_region("chat")

    def select_captcha(self):
        self.select_region("captcha")

    def edit_nicknames(self):
        if self.worker and self.worker.is_alive():
            messagebox.showinfo("Detene la alarma", "Primero apreta Detener para editar los nicknames.")
            return
        current = "; ".join(self.config.get("nicknames", []))
        value = simpledialog.askstring(
            "Nicknames de administradores",
            "Escribi los nicknames que queres vigilar separados por un punto y coma ;",
            initialvalue=current,
            parent=self.root,
        )
        if value is None:
            return
        names = []
        seen = set()
        for item in value.split(";"):
            name = item.strip()
            key = name.casefold()
            if name and key not in seen:
                names.append(name)
                seen.add(key)
        self.config["nicknames"] = names
        self.save_settings()
        self.refresh_nickname_label()
        if names:
            self.add_log("Nicknames vigilados: " + "; ".join(names))
        else:
            self.add_log("No se configuraron nicknames; se mantiene el filtro de canales.")

    def choose_sound(self, kind):
        if self.worker and self.worker.is_alive():
            messagebox.showinfo("Detene la alarma", "Primero apreta Detener para cambiar los sonidos.")
            return
        prompt = "captcha" if kind == "captcha" else "chat"
        selected = filedialog.askopenfilename(
            parent=self.root,
            title=f"Elegi el sonido WAV para {prompt}",
            filetypes=[("Archivos de sonido WAV", "*.wav")],
        )
        if not selected:
            return
        if Path(selected).suffix.casefold() != ".wav":
            messagebox.showerror("Archivo no valido", "Elegi un archivo con formato .wav.")
            return
        target = CUSTOM_CAPTCHA_SOUND if kind == "captcha" else CUSTOM_CHAT_SOUND
        try:
            if Path(selected).resolve() != target.resolve():
                shutil.copy2(selected, target)
            self.config[f"{kind}_sound_label"] = Path(selected).name
            self.save_settings()
            self.refresh_file_labels()
            self.add_log(f"Sonido de {prompt} actualizado: {Path(selected).name}")
        except Exception as exc:
            messagebox.showerror("No se pudo copiar el sonido", str(exc))

    def sound_path(self, kind):
        custom_path = CUSTOM_CAPTCHA_SOUND if kind == "captcha" else CUSTOM_CHAT_SOUND
        if custom_path.exists():
            return custom_path
        return asset("alarm.wav" if kind == "captcha" else "chat.wav")

    def test_sound(self, kind):
        path = self.sound_path(kind)
        try:
            winsound.PlaySound(None, 0)
            winsound.PlaySound(
                str(path), winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT
            )
            self.add_log(f"Probando sonido de {kind}: {path.name}")
        except Exception as exc:
            messagebox.showerror("Error de sonido", str(exc))

    def start(self):
        if self.starting or (self.worker and self.worker.is_alive()):
            return
        try:
            topic = self.ntfy_var.get().strip() if self.ntfy_enabled.get() else ""
            if self.ntfy_enabled.get() and not topic:
                raise RuntimeError("Escribi tu codigo de ntfy o desactiva los avisos al celular.")
            self.persist_ntfy()
            n, monitor = self.chosen()
            template_path, custom_template = self.captcha_template_path()
            if custom_template:
                if self.config.get("captcha_monitor") != n:
                    raise RuntimeError(
                        "La captura del captcha se hizo en otro monitor. Elegi ese monitor "
                        "o captura de nuevo el captcha en el monitor seleccionado."
                    )
            if not template_path.exists():
                raise RuntimeError("No encuentro la captura del captcha.")
            template = cv2.imdecode(
                np.fromfile(str(template_path), dtype=np.uint8), cv2.IMREAD_GRAYSCALE
            )
            if template is None or template.size == 0 or template.std() < 1:
                raise RuntimeError("La captura del captcha no es una imagen valida.")
            if template.shape[0] > monitor["height"] or template.shape[1] > monitor["width"]:
                raise RuntimeError("La captura del captcha es mas grande que el monitor.")
            self.config["monitor"] = n
            self.save_settings()
            nicknames = list(self.config.get("nicknames", []))
            self.stop_event = threading.Event()
            self.starting = True
            self.status.set("Preparando alarma...")
            self.status_label.configure(text_color="#fbbf24")
            self.set_running_controls(True)
            template_info = (
                f"{'personalizada' if custom_template else 'incluida'} "
                f"({template.shape[1]} x {template.shape[0]} px)"
            )
            self.start_task = threading.Thread(
                target=self.prepare_start,
                args=(
                    n, monitor, template, template_info, nicknames, topic,
                    self.config.get("chat_monitor"), self.stop_event,
                ),
                daemon=True,
            )
            self.start_task.start()
            self.add_log("Preparando la alarma en segundo plano.")
        except Exception as exc:
            self.starting = False
            self.status.set("Detenida")
            self.status_label.configure(text_color="#f87171")
            self.set_running_controls(False)
            messagebox.showerror("No se pudo iniciar", str(exc))

    def prepare_start(self, n, monitor, template, template_info, nicknames, topic,
                      chat_monitor, stop):
        try:
            try:
                engine = load_ocr()
            except Exception as exc:
                engine = None
                self.events.put(("log", "Aviso de chat desactivado; Tesseract: " + str(exc)))

            if stop.is_set():
                self.events.put(("startup_cancelled", None))
                return

            area = None
            if engine and CHAT_AREA.exists() and chat_monitor == n:
                try:
                    x, y, w, h = json.loads(CHAT_AREA.read_text(encoding="utf-8"))
                    if (
                        x >= 0 and y >= 0 and w > 0 and h > 0
                        and x + w <= monitor["width"]
                        and y + h <= monitor["height"]
                    ):
                        area = (x, y, w, h)
                    else:
                        self.events.put(("log", "Area del chat fuera del monitor; chat desactivado."))
                except Exception as exc:
                    self.events.put(("log", "Area del chat no valida: " + str(exc)))
            elif engine and CHAT_AREA.exists():
                self.events.put(("log", "Selecciona de nuevo el chat para este monitor."))

            self.events.put((
                "startup_ready",
                {
                    "n": n,
                    "monitor": monitor,
                    "template": template,
                    "template_info": template_info,
                    "engine": engine,
                    "area": area,
                    "nicknames": nicknames,
                    "topic": topic,
                    "stop": stop,
                },
            ))
        except Exception as exc:
            self.events.put(("startup_error", str(exc)))

    def finish_start(self, prepared):
        self.starting = False
        stop = prepared["stop"]
        if stop.is_set():
            self.status.set("Detenida")
            self.status_label.configure(text_color="#f87171")
            self.set_running_controls(False)
            return
        n = prepared["n"]
        area = prepared["area"]
        self.worker = threading.Thread(
            target=self.watch,
            args=(
                n, prepared["monitor"], prepared["template"], prepared["engine"],
                area, prepared["nicknames"], prepared["topic"], stop,
            ),
            daemon=True,
        )
        try:
            self.worker.start()
        except Exception as exc:
            self.starting = False
            self.status.set("Detenida")
            self.status_label.configure(text_color="#f87171")
            self.set_running_controls(False)
            messagebox.showerror("No se pudo iniciar", str(exc))
            return
        self.status.set(f"Vigilando monitor {n}")
        self.status_label.configure(text_color="#34d399")
        self.set_running_controls(True)
        mode = "Nicknames: " + "; ".join(prepared["nicknames"]) if prepared["nicknames"] else "canales habituales"
        self.add_log(
            f"Alarma iniciada en monitor {n}. Captcha activo; "
            f"plantilla {prepared['template_info']}. "
            + (f"Chat de administradores activo ({mode})." if area else "Chat desactivado.")
        )

    def set_running_controls(self, running):
        self.start_btn.configure(state="disabled" if running else "normal")
        self.stop_btn.configure(state="normal" if running else "disabled")
        self.monitor_combo.configure(state="disabled" if running else "readonly")
        for widget in (
            self.select_chat_btn, self.nicknames_btn, self.select_captcha_btn,
            self.captcha_sound_btn, self.chat_sound_btn, self.test_captcha_btn, self.test_chat_btn,
        ):
            widget.configure(state="disabled" if running else "normal")

    def watch(self, n, monitor, template, engine, area, nicknames, topic, stop):
        notices = queue.Queue(maxsize=10)
        if topic:
            threading.Thread(
                target=self.phone_worker, args=(notices, stop), daemon=True
            ).start()
        jobs = queue.Queue(maxsize=1)
        results = queue.Queue()
        if engine and area:
            threading.Thread(
                target=self.ocr_worker,
                args=(engine, jobs, results, nicknames, stop), daemon=True,
            ).start()
        active = False
        looping = False
        pending = False
        last_chat = last_fallback = 0
        sct = None
        capture_recovering = False
        last_capture_log = 0.0
        try:
            while not stop.is_set():
                try:
                    # Recreate the MSS session after a Windows BitBlt failure.
                    if sct is None:
                        sct = mss.mss()
                    if n >= len(sct.monitors):
                        raise RuntimeError("El monitor ya no esta disponible.")
                    monitor = sct.monitors[n]
                    frame = np.array(sct.grab(monitor))[:, :, :3]
                except Exception as exc:
                    if sct is not None:
                        try:
                            sct.close()
                        except Exception:
                            pass
                        sct = None
                    now = time.monotonic()
                    if not capture_recovering or now - last_capture_log >= 15:
                        self.events.put((
                            "log",
                            "Fallo al capturar la pantalla; Umbral va a reintentar "
                            "automaticamente. Detalle: " + str(exc),
                        ))
                        last_capture_log = now
                    capture_recovering = True
                    stop.wait(1.0)
                    continue

                if capture_recovering:
                    self.events.put(("log", "Captura de pantalla recuperada; vigilancia reanudada."))
                    capture_recovering = False

                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                score = float(cv2.matchTemplate(gray, template, cv2.TM_CCOEFF_NORMED).max())
                found = score >= THRESHOLD
                now = time.monotonic()
                if found and not active:
                    active = True
                    self.events.put(("log", f"Captcha detectado ({score:.2f})."))
                    looping = self.play("captcha", True)
                    last_fallback = now
                    self.send_notice(notices, topic, "Umbral", "Captcha visible en Lineage 2.")
                elif not found and active:
                    active = False
                    winsound.PlaySound(None, 0)
                    self.events.put(("log", "Captcha ya no visible."))
                if active and not looping and now - last_fallback >= 2:
                    winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
                    last_fallback = now
                if area and now - last_chat >= CHAT_INTERVAL and jobs.empty():
                    x, y, w, h = area
                    try:
                        jobs.put_nowait(frame[y:y + h, x:x + w].copy())
                        last_chat = now
                    except queue.Full:
                        pass
                while True:
                    try:
                        kind, value = results.get_nowait()
                    except queue.Empty:
                        break
                    if kind == "error":
                        self.events.put(("log", "Error leyendo chat: " + value))
                        continue
                    for line in value:
                        self.events.put(("log", "Chat de administrador: " + line))
                    pending = True
                    self.send_notice(notices, topic, "Umbral", "Admin en el chat.")
                if pending and not active:
                    self.play("chat")
                    pending = False
                stop.wait(CAPTCHA_INTERVAL)
        except Exception as exc:
            self.events.put(("log", "Error: " + str(exc)))
        finally:
            if sct is not None:
                try:
                    sct.close()
                except Exception:
                    pass
            winsound.PlaySound(None, 0)
            self.events.put(("stopped", None))

    def ocr_worker(self, engine, jobs, results, nicknames, stop):
        seen = {}
        first = True
        while not stop.is_set():
            try:
                frame = jobs.get(timeout=0.25)
            except queue.Empty:
                continue
            try:
                hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
                mask = cv2.inRange(hsv, np.array([0, 0, 140]), np.array([179, 255, 255]))
                pic = cv2.resize(255 - mask, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
                text = engine.image_to_string(pic, lang="eng", config="--psm 6", timeout=8)
                now = time.monotonic()
                seen = {key: stamp for key, stamp in seen.items() if now - stamp < 15}
                alerts = []
                for line in text.splitlines():
                    line = line.strip()
                    if not line or not self.is_watched_line(line, nicknames):
                        continue
                    key = re.sub(r"[^\w]", "", line.casefold())
                    matches = [
                        previous for previous in seen
                        if SequenceMatcher(None, key, previous).ratio() >= 0.96
                    ]
                    if not matches and not first:
                        alerts.append(line)
                    for previous in matches:
                        seen[previous] = now
                    seen[key] = now
                if alerts:
                    results.put(("messages", alerts))
                first = False
            except Exception as exc:
                results.put(("error", str(exc)))

    @staticmethod
    def is_watched_line(line, nicknames):
        if not nicknames:
            return bool(CHANNEL_PATTERN.search(line))
        for name in nicknames:
            # El nombre debe aparecer como emisor, seguido por dos puntos.
            pattern = rf"(?<!\w){re.escape(name)}\s*:"
            if re.search(pattern, line, flags=re.I):
                return True
        return False

    def play(self, kind, loop=False):
        path = self.sound_path(kind)
        if path.exists():
            flags = winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT
            if loop:
                flags |= winsound.SND_LOOP
            try:
                winsound.PlaySound(str(path), flags)
                return True
            except Exception as exc:
                self.events.put(("log", f"No se pudo reproducir {path.name}: {exc}"))
        winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
        return False

    def send_notice(self, jobs, topic, title, message):
        if not topic:
            return
        try:
            jobs.put_nowait((topic, title, message))
        except queue.Full:
            self.events.put(("log", "Cola de avisos al celular llena."))

    def phone_worker(self, jobs, stop):
        while not stop.is_set():
            try:
                topic, title, message = jobs.get(timeout=0.25)
            except queue.Empty:
                continue
            try:
                req = urllib.request.Request(
                    "https://ntfy.sh/" + topic,
                    data=message.encode("utf-8"),
                    headers={"Title": title, "Priority": "urgent"},
                )
                with urllib.request.urlopen(req, timeout=5):
                    pass
            except Exception as exc:
                self.events.put(("log", "No pude avisar al celular: " + str(exc)))

    def stop(self):
        if self.stop_event:
            self.stop_event.set()
        self.status.set("Deteniendo…")
        self.status_label.configure(text_color="#fbbf24")

    def process_events(self):
        try:
            while True:
                kind, message = self.events.get_nowait()
                if kind == "log":
                    self.add_log(message)
                elif kind == "startup_ready":
                    self.finish_start(message)
                elif kind == "startup_cancelled":
                    self.starting = False
                    self.status.set("Detenida")
                    self.status_label.configure(text_color="#f87171")
                    self.set_running_controls(False)
                elif kind == "startup_error":
                    self.starting = False
                    self.status.set("Detenida")
                    self.status_label.configure(text_color="#f87171")
                    self.set_running_controls(False)
                    messagebox.showerror("No se pudo iniciar", message)
                elif kind == "stopped":
                    self.starting = False
                    self.status.set("Detenida")
                    self.status_label.configure(text_color="#f87171")
                    self.set_running_controls(False)
        except queue.Empty:
            pass
        self.root.after(150, self.process_events)

    def close(self):
        if self.stop_event:
            self.stop_event.set()
        winsound.PlaySound(None, 0)
        self.root.destroy()


if __name__ == "__main__":
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Umbral.AlertApp")
        except Exception:
            pass
    root = ctk.CTk()
    AlarmUI(root)
    root.mainloop()
