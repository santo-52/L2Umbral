@echo off
cd /d "%~dp0"
title Instalador - Umbral
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Umbral_Datos\_setup\instalar.ps1"
if errorlevel 1 (
  echo.
  echo No se pudo terminar la instalacion. Sacale una foto a esta ventana y mandala.
  pause
)
